using System.Runtime.InteropServices;

namespace FocusTime
{
    public partial class TelaPrincipal : Form
    {
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        public TelaPrincipal()
        {
            InitializeComponent();
        }

        public void AdicionarUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            pnlFill.Controls.Clear();
            pnlFill.Controls.Add(userControl);
            userControl.BringToFront();
        }

        private void pbxLogo_Click(object sender, EventArgs e)
        {
            TelaCadastro cadastro = new TelaCadastro(this);
            AdicionarUserControl(cadastro);
        }


        private void pbxFechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void pnlSuperior_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }
    }
}
