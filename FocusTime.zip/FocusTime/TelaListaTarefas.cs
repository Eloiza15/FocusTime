﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FocusTime
{
    public partial class TelaListaTarefas : UserControl
    {
        private TelaPrincipal formprincipal;
        public TelaListaTarefas(TelaPrincipal formprincipal)
        {
            InitializeComponent();
            this.formprincipal = formprincipal;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {

        }
    }
}
