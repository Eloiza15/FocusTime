﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace FocusTime
{
    public partial class TelaListaTarefas : UserControl
    {
        private TelaPrincipal formprincipal;
        public TelaListaTarefas(TelaPrincipal formprincipal)
        {
            InitializeComponent();
            this.formprincipal = formprincipal;
        }

        private void LimparCampos()
        {
            txtId.Clear();
            txtTitulo.Clear();
            txtDescricao.Clear();
            mtxtDataLimite.Clear();
            cbxStatus.SelectedIndex = -1;
        }

        private void TelaListaTarefas_Load(object sender, EventArgs e)
        {
            Tarefas tarefas = new Tarefas();
            tarefas.ListarTarefas(dgvTarefas);
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(txtTitulo.Text))
                {
                    string nomeTarefa = txtTitulo.Text;
                    string descricao = txtDescricao.Text;
                    string dataLimite = mtxtDataLimite.Text;
                    string statusTarefa = cbxStatus.SelectedItem.ToString();

                    Tarefas tarefas = new Tarefas(nomeTarefa, descricao, dataLimite, statusTarefa);
                    if (!tarefas.SalvarTarefa())
                    {
                        MessageBox.Show("Não foi possível salvar a tarefa.");
                        return;
                    }
                    MessageBox.Show("Tarefa salva com sucesso!");

                    Tarefas tarefa = new Tarefas();
                    tarefas.ListarTarefas(dgvTarefas);

                    LimparCampos();
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos obrigatórios.");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao salvar a tarefa: " + ex.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(txtId.Text) && !string.IsNullOrWhiteSpace(txtTitulo.Text))
                {
                    string nomeTarefa = txtTitulo.Text;
                    string descricao = txtDescricao.Text;
                    string dataLimite = mtxtDataLimite.Text;
                    int.TryParse(txtId.Text, out int idTarefa);

                    if (cbxStatus.SelectedIndex == -1)
                    {
                        MessageBox.Show("Selecione um status para a tarefa.");
                        return;
                    }

                    string statusTarefa = cbxStatus.SelectedItem.ToString();

                    Tarefas tarefas = new Tarefas(nomeTarefa, descricao, dataLimite, statusTarefa);

                    if (!tarefas.EditarTarefa(idTarefa))
                    {
                        MessageBox.Show("Não foi possível editar a tarefa.");
                        return;
                    }

                    MessageBox.Show("Tarefa editada com sucesso!");

                    Tarefas tarefa = new Tarefas();
                    tarefas.ListarTarefas(dgvTarefas);

                    LimparCampos();
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos obrigatórios.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao editar a tarefa: " + ex.Message);
            }

        }

        private void dgvTarefas_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dgvTarefas.Rows[e.RowIndex];
                    txtId.Text = row.Cells["id_tarefa"].Value.ToString();
                    txtTitulo.Text = row.Cells["titulo"].Value.ToString();
                    txtDescricao.Text = row.Cells["descricao"].Value.ToString();
                    mtxtDataLimite.Text = row.Cells["data_limite"].Value.ToString();
                    cbxStatus.SelectedItem = row.Cells["status_tarefa"].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao selecionar livro: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(txtId.Text) && !string.IsNullOrWhiteSpace(txtTitulo.Text))
                {
                    string nomeTarefa = txtTitulo.Text;
                    string descricao = txtDescricao.Text;
                    string dataLimite = mtxtDataLimite.Text;
                    int.TryParse(txtId.Text, out int idTarefa);

                    if (cbxStatus.SelectedIndex == -1)
                    {
                        MessageBox.Show("Selecione um status para a tarefa.");
                        return;
                    }

                    string statusTarefa = cbxStatus.SelectedItem.ToString();

                    Tarefas tarefas = new Tarefas(nomeTarefa, descricao, dataLimite, statusTarefa);

                    if (!tarefas.DeletarTarefa(idTarefa))
                    {
                        MessageBox.Show("Não foi possível excluir a tarefa.");
                        return;
                    }

                    MessageBox.Show("Tarefa excluída com sucesso!");

                    Tarefas tarefa = new Tarefas();
                    tarefas.ListarTarefas(dgvTarefas);

                    LimparCampos();
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos obrigatórios.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir a tarefa: " + ex.Message);
            }
        }
    }
}
