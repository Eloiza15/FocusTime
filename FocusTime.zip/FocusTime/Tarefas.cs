﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace FocusTime
{
    public class Tarefas
    {
        private string Titulo { get; set; }
        private string Descricao { get; set; }
        private string DataLimite { get; set; }
        private string Status { get; set; }

        public Tarefas(string titulo, string descricao, string data_limite, string status_tarefa)
        {
            this.Titulo = titulo;
            this.Descricao = descricao;
            this.DataLimite = data_limite;
            this.Status = status_tarefa;
        }

        public Tarefas()
        {

        }

        public bool ListarTarefas(DataGridView dataGrid)
        {
            try
            {
                using (MySqlConnection conexaoBanco = new ConexaoBD().Conectar())
                {
                    string listar = "select * from tarefas";
                    MySqlCommand comando = new MySqlCommand(listar, conexaoBanco);
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);
                    dataGrid.DataSource = tabela;

                    // Configurações do DataGridView
                    dataGrid.AllowUserToAddRows = false;
                    dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    dataGrid.AutoResizeColumns();
                    dataGrid.ClearSelection();

                    if (dataGrid.Rows.Count > 0)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Nenhuma tarefa encontrada.", "Lista vazia", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao listar as tarefas:\n" + ex.Message, "Erro de listagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public bool SalvarTarefa()
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBD().Conectar())
                {
                    string query = "INSERT INTO tarefas (titulo, descricao, data_limite, status_tarefa) VALUES (@titulo, @descricao, @data_limite, @status_tarefa)";
                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@titulo", Titulo);
                    comando.Parameters.AddWithValue("@descricao", Descricao);
                    comando.Parameters.AddWithValue("@data_limite", DataLimite);
                    comando.Parameters.AddWithValue("@status_tarefa", Status);
                    return comando.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao salvar tarefa: " + ex.Message);
                return false;
            }
        }

        public bool EditarTarefa(int id)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBD().Conectar())
                {
                    string query = "UPDATE tarefas SET titulo = @titulo, descricao = @descricao, data_limite = @data_limite, status_tarefa = @status_tarefa WHERE id_tarefa = @id_tarefa";
                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@titulo", Titulo);
                    comando.Parameters.AddWithValue("@descricao", Descricao);
                    comando.Parameters.AddWithValue("@data_limite", DataLimite);
                    comando.Parameters.AddWithValue("@status_tarefa", Status);
                    comando.Parameters.AddWithValue("@id_tarefa", id);

                    return comando.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao editar tarefa: " + ex.Message);
                return false;
            }
        }

        public bool DeletarTarefa(int id)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBD().Conectar())
                {
                    string query = "DELETE FROM tarefas WHERE id_tarefa = @id_tarefa";
                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@id_tarefa", id);
                    return comando.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao deletar tarefa: " + ex.Message);
                return false;
            }

        }
    }
}

        
