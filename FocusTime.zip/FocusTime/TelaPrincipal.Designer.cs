﻿namespace FocusTime
{
    partial class TelaPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaPrincipal));
            pnlSuperior = new Panel();
            pbxFechar = new PictureBox();
            pictureBox1 = new PictureBox();
            pnlFill = new Panel();
            pbxLogo = new PictureBox();
            lblSlogan = new Label();
            lblNomePrograma = new Label();
            pnlSuperior.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbxFechar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlFill.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbxLogo).BeginInit();
            SuspendLayout();
            // 
            // pnlSuperior
            // 
            pnlSuperior.BackColor = Color.DarkSlateGray;
            pnlSuperior.Controls.Add(pbxFechar);
            pnlSuperior.Controls.Add(pictureBox1);
            pnlSuperior.Dock = DockStyle.Top;
            pnlSuperior.Location = new Point(0, 0);
            pnlSuperior.Name = "pnlSuperior";
            pnlSuperior.Size = new Size(625, 33);
            pnlSuperior.TabIndex = 2;
            pnlSuperior.MouseDown += pnlSuperior_MouseDown;
            // 
            // pbxFechar
            // 
            pbxFechar.Image = Properties.Resources.icons8_excluir_24__1_;
            pbxFechar.Location = new Point(598, 3);
            pbxFechar.Name = "pbxFechar";
            pbxFechar.Size = new Size(24, 24);
            pbxFechar.SizeMode = PictureBoxSizeMode.AutoSize;
            pbxFechar.TabIndex = 0;
            pbxFechar.TabStop = false;
            pbxFechar.Click += pbxFechar_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_linha_horizontal_24;
            pictureBox1.Location = new Point(568, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(24, 24);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pnlFill
            // 
            pnlFill.BackColor = Color.LightGray;
            pnlFill.Controls.Add(pbxLogo);
            pnlFill.Controls.Add(lblSlogan);
            pnlFill.Controls.Add(lblNomePrograma);
            pnlFill.Dock = DockStyle.Fill;
            pnlFill.Location = new Point(0, 33);
            pnlFill.Name = "pnlFill";
            pnlFill.Size = new Size(625, 327);
            pnlFill.TabIndex = 1;
            // 
            // pbxLogo
            // 
            pbxLogo.Image = Properties.Resources.FocusTimeLogo2;
            pbxLogo.Location = new Point(225, 25);
            pbxLogo.Name = "pbxLogo";
            pbxLogo.Size = new Size(172, 175);
            pbxLogo.SizeMode = PictureBoxSizeMode.Zoom;
            pbxLogo.TabIndex = 2;
            pbxLogo.TabStop = false;
            pbxLogo.Click += pbxLogo_Click;
            // 
            // lblSlogan
            // 
            lblSlogan.AutoSize = true;
            lblSlogan.Font = new Font("Segoe UI", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblSlogan.Location = new Point(157, 245);
            lblSlogan.Name = "lblSlogan";
            lblSlogan.Size = new Size(301, 21);
            lblSlogan.TabIndex = 1;
            lblSlogan.Text = "Organize suas tarefas. Domine seu tempo.";
            // 
            // lblNomePrograma
            // 
            lblNomePrograma.AutoSize = true;
            lblNomePrograma.Font = new Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNomePrograma.ForeColor = Color.FromArgb(59, 130, 246);
            lblNomePrograma.Location = new Point(251, 193);
            lblNomePrograma.Name = "lblNomePrograma";
            lblNomePrograma.Size = new Size(122, 30);
            lblNomePrograma.TabIndex = 0;
            lblNomePrograma.Text = "FocusTime";
            // 
            // TelaPrincipal
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(625, 360);
            Controls.Add(pnlFill);
            Controls.Add(pnlSuperior);
            Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4);
            Name = "TelaPrincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FocusTime";
            pnlSuperior.ResumeLayout(false);
            pnlSuperior.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbxFechar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlFill.ResumeLayout(false);
            pnlFill.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbxLogo).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlSuperior;
        private Panel pnlFill;
        private PictureBox pictureBox1;
        private PictureBox pbxFechar;
        private Label lblSlogan;
        private PictureBox pbxLogo;
        private Label lblNomePrograma;
    }
}
