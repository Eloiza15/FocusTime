﻿namespace FocusTime
{
    partial class TelaRedefinirSenha
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            gbxRedefinirSenha = new GroupBox();
            btnVoltar = new Button();
            txtSenha = new TextBox();
            txtEmail = new TextBox();
            btnRedefinir = new Button();
            lblSenha = new Label();
            lblEmail = new Label();
            pictureBox1 = new PictureBox();
            gbxRedefinirSenha.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // gbxRedefinirSenha
            // 
            gbxRedefinirSenha.BackColor = Color.White;
            gbxRedefinirSenha.Controls.Add(btnVoltar);
            gbxRedefinirSenha.Controls.Add(txtSenha);
            gbxRedefinirSenha.Controls.Add(txtEmail);
            gbxRedefinirSenha.Controls.Add(btnRedefinir);
            gbxRedefinirSenha.Controls.Add(lblSenha);
            gbxRedefinirSenha.Controls.Add(lblEmail);
            gbxRedefinirSenha.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gbxRedefinirSenha.Location = new Point(41, 56);
            gbxRedefinirSenha.Margin = new Padding(2);
            gbxRedefinirSenha.Name = "gbxRedefinirSenha";
            gbxRedefinirSenha.Padding = new Padding(2);
            gbxRedefinirSenha.Size = new Size(300, 219);
            gbxRedefinirSenha.TabIndex = 3;
            gbxRedefinirSenha.TabStop = false;
            gbxRedefinirSenha.Text = "Redefinir Senha";
            // 
            // btnVoltar
            // 
            btnVoltar.BackColor = Color.DarkSlateGray;
            btnVoltar.ForeColor = SystemColors.Window;
            btnVoltar.Location = new Point(107, 182);
            btnVoltar.Margin = new Padding(2);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(69, 26);
            btnVoltar.TabIndex = 4;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = false;
            btnVoltar.Click += btnVoltar_Click;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(107, 92);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(167, 23);
            txtSenha.TabIndex = 2;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(73, 54);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(201, 23);
            txtEmail.TabIndex = 1;
            // 
            // btnRedefinir
            // 
            btnRedefinir.BackColor = Color.FromArgb(59, 130, 246);
            btnRedefinir.ForeColor = SystemColors.Window;
            btnRedefinir.Location = new Point(84, 141);
            btnRedefinir.Margin = new Padding(2);
            btnRedefinir.Name = "btnRedefinir";
            btnRedefinir.Size = new Size(126, 28);
            btnRedefinir.TabIndex = 3;
            btnRedefinir.Text = "Redefinir Senha";
            btnRedefinir.UseVisualStyleBackColor = false;
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(21, 94);
            lblSenha.Margin = new Padding(2, 0, 2, 0);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(73, 15);
            lblSenha.TabIndex = 3;
            lblSenha.Text = "Nova Senha:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(21, 56);
            lblEmail.Margin = new Padding(2, 0, 2, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(44, 15);
            lblEmail.TabIndex = 1;
            lblEmail.Text = "E-mail:";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.FocusTimeLogo2;
            pictureBox1.Location = new Point(365, 66);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(227, 198);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // TelaRedefinirSenha
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            Controls.Add(pictureBox1);
            Controls.Add(gbxRedefinirSenha);
            Margin = new Padding(2);
            Name = "TelaRedefinirSenha";
            Size = new Size(625, 327);
            gbxRedefinirSenha.ResumeLayout(false);
            gbxRedefinirSenha.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox gbxRedefinirSenha;
        private TextBox txtSenha;
        private TextBox txtEmail;
        private Button btnRedefinir;
        private Label lblSenha;
        private Label lblEmail;
        private PictureBox pictureBox1;
        private Button btnVoltar;
    }
}
