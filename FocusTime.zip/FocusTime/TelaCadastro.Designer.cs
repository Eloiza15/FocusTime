﻿namespace FocusTime
{
    partial class TelaCadastro
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            gbxCadastro = new GroupBox();
            lblNome = new Label();
            lblLogin = new Label();
            lblEmail = new Label();
            lblSenha = new Label();
            btnCadastrar = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            gbxCadastro.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.FocusTimeLogo2;
            pictureBox1.Location = new Point(519, 76);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(324, 330);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // gbxCadastro
            // 
            gbxCadastro.BackColor = Color.White;
            gbxCadastro.Controls.Add(btnCadastrar);
            gbxCadastro.Controls.Add(lblSenha);
            gbxCadastro.Controls.Add(lblEmail);
            gbxCadastro.Controls.Add(lblLogin);
            gbxCadastro.Controls.Add(lblNome);
            gbxCadastro.Location = new Point(60, 76);
            gbxCadastro.Name = "gbxCadastro";
            gbxCadastro.Size = new Size(429, 330);
            gbxCadastro.TabIndex = 1;
            gbxCadastro.TabStop = false;
            gbxCadastro.Text = "Cadastro";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(32, 68);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(65, 25);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome:";
            // 
            // lblLogin
            // 
            lblLogin.AutoSize = true;
            lblLogin.Location = new Point(32, 165);
            lblLogin.Name = "lblLogin";
            lblLogin.Size = new Size(60, 25);
            lblLogin.TabIndex = 1;
            lblLogin.Text = "Login:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(32, 118);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(65, 25);
            lblEmail.TabIndex = 2;
            lblEmail.Text = "E-mail:";
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(33, 219);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(64, 25);
            lblSenha.TabIndex = 3;
            lblSenha.Text = "Senha:";
            // 
            // btnCadastrar
            // 
            btnCadastrar.ForeColor = SystemColors.ActiveCaptionText;
            btnCadastrar.Location = new Point(160, 268);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(112, 34);
            btnCadastrar.TabIndex = 4;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.UseVisualStyleBackColor = true;
            // 
            // TelaCadastro
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            Controls.Add(gbxCadastro);
            Controls.Add(pictureBox1);
            Name = "TelaCadastro";
            Size = new Size(893, 480);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            gbxCadastro.ResumeLayout(false);
            gbxCadastro.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private GroupBox gbxCadastro;
        private Label lblEmail;
        private Label lblLogin;
        private Label lblNome;
        private Button btnCadastrar;
        private Label lblSenha;
    }
}
