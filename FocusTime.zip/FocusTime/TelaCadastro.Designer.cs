﻿namespace FocusTime
{
    partial class TelaCadastro
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            gbxCadastro = new GroupBox();
            txtSenha = new TextBox();
            txtLogin = new TextBox();
            txtEmail = new TextBox();
            txtNome = new TextBox();
            llblLogin = new LinkLabel();
            btnCadastrar = new Button();
            lblSenha = new Label();
            lblEmail = new Label();
            lblLogin = new Label();
            lblNome = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            gbxCadastro.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.FocusTimeLogo2;
            pictureBox1.Location = new Point(363, 52);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(227, 224);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // gbxCadastro
            // 
            gbxCadastro.BackColor = Color.White;
            gbxCadastro.Controls.Add(txtSenha);
            gbxCadastro.Controls.Add(txtLogin);
            gbxCadastro.Controls.Add(txtEmail);
            gbxCadastro.Controls.Add(txtNome);
            gbxCadastro.Controls.Add(llblLogin);
            gbxCadastro.Controls.Add(btnCadastrar);
            gbxCadastro.Controls.Add(lblSenha);
            gbxCadastro.Controls.Add(lblEmail);
            gbxCadastro.Controls.Add(lblLogin);
            gbxCadastro.Controls.Add(lblNome);
            gbxCadastro.Location = new Point(34, 42);
            gbxCadastro.Margin = new Padding(2);
            gbxCadastro.Name = "gbxCadastro";
            gbxCadastro.Padding = new Padding(2);
            gbxCadastro.Size = new Size(300, 248);
            gbxCadastro.TabIndex = 1;
            gbxCadastro.TabStop = false;
            gbxCadastro.Text = "Cadastro";
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(74, 146);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(201, 25);
            txtSenha.TabIndex = 4;
            // 
            // txtLogin
            // 
            txtLogin.Location = new Point(74, 109);
            txtLogin.Name = "txtLogin";
            txtLogin.Size = new Size(201, 25);
            txtLogin.TabIndex = 3;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(74, 77);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(201, 25);
            txtEmail.TabIndex = 2;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(74, 43);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(201, 25);
            txtNome.TabIndex = 1;
            // 
            // llblLogin
            // 
            llblLogin.AutoSize = true;
            llblLogin.Location = new Point(51, 216);
            llblLogin.Name = "llblLogin";
            llblLogin.Size = new Size(201, 17);
            llblLogin.TabIndex = 5;
            llblLogin.TabStop = true;
            llblLogin.Text = "Já é cadastrado? Faça seu Login!";
            // 
            // btnCadastrar
            // 
            btnCadastrar.BackColor = Color.FromArgb(59, 130, 246);
            btnCadastrar.ForeColor = SystemColors.Window;
            btnCadastrar.Location = new Point(110, 176);
            btnCadastrar.Margin = new Padding(2);
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.Size = new Size(78, 27);
            btnCadastrar.TabIndex = 4;
            btnCadastrar.Text = "Cadastrar";
            btnCadastrar.UseVisualStyleBackColor = false;
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(23, 149);
            lblSenha.Margin = new Padding(2, 0, 2, 0);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(46, 17);
            lblSenha.TabIndex = 3;
            lblSenha.Text = "Senha:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(22, 80);
            lblEmail.Margin = new Padding(2, 0, 2, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(47, 17);
            lblEmail.TabIndex = 2;
            lblEmail.Text = "E-mail:";
            // 
            // lblLogin
            // 
            lblLogin.AutoSize = true;
            lblLogin.Location = new Point(22, 112);
            lblLogin.Margin = new Padding(2, 0, 2, 0);
            lblLogin.Name = "lblLogin";
            lblLogin.Size = new Size(43, 17);
            lblLogin.TabIndex = 1;
            lblLogin.Text = "Login:";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(22, 46);
            lblNome.Margin = new Padding(2, 0, 2, 0);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(47, 17);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome:";
            // 
            // TelaCadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            Controls.Add(gbxCadastro);
            Controls.Add(pictureBox1);
            Margin = new Padding(2);
            Name = "TelaCadastro";
            Size = new Size(625, 327);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            gbxCadastro.ResumeLayout(false);
            gbxCadastro.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private GroupBox gbxCadastro;
        private Label lblEmail;
        private Label lblLogin;
        private Label lblNome;
        private Button btnCadastrar;
        private Label lblSenha;
        private TextBox txtSenha;
        private TextBox txtLogin;
        private TextBox txtEmail;
        private TextBox txtNome;
        private LinkLabel llblLogin;
    }
}
