﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Security.Cryptography;
using MySql.Data.MySqlClient;


namespace FocusTime
{
    public class Usuarios
    {
        private string Nome { get; set; }
        private string Email { get; set; }
        private string Login { get; set; }
        private string Senha { get; set; }
        public Usuarios(string nome, string email, string login, string senha)
        {
            this.Nome = nome;
            this.Email = email;
            this.Login = login;
            this.Senha = senha;
        }
        public Usuarios(string loginOuEmail, string senha)
        {
            if (loginOuEmail.Contains("@"))
                Email = loginOuEmail;
            else
                Login = loginOuEmail;

            Senha = senha;
        }

        public static bool verificarEmail(string email)
        {
            string emailValido = @"^[a-zA-Z0-9._%+-]+@[a-zAZ0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(emailValido);
            return regex.IsMatch(email);
        }

        public static string CriptografarSenha(string senha)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(System.Text.Encoding.UTF8.GetBytes(senha));
                return string.Concat(bytes.Select(b => b.ToString("x2")));
            }
        }

        public static bool LoginOuEmailExistem(string login, string email)
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBD().Conectar())
                {
                    string query = "SELECT COUNT(*) FROM usuarios WHERE login = @login OR email = @email";
                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@login", login);
                    comando.Parameters.AddWithValue("@email", email);

                    long count = (long)comando.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao verificar login/email: " + ex.Message);
                return false;
            }
        }

        public bool CadastrarUsuario()
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBD().Conectar())
                {
                    string query = "INSERT INTO usuarios (nome, email, login, senha) VALUES (@nome, @email, @login, @senha)";
                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@nome", this.Nome);
                    comando.Parameters.AddWithValue("@email", this.Email);
                    comando.Parameters.AddWithValue("@login", this.Login);
                    comando.Parameters.AddWithValue("@senha", CriptografarSenha(this.Senha));

                    return comando.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao cadastrar usuário: " + ex.Message);
                return false;
            }
        }

        public bool FazerLogin()
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBD().Conectar())
                {
                    string query = "SELECT COUNT(*) FROM usuarios WHERE (login = @login OR email = @email) AND senha = @senha";
                    MySqlCommand comando = new MySqlCommand(query, conexao);

                    comando.Parameters.AddWithValue("@login", this.Login ?? "");   // usa vazio se for null
                    comando.Parameters.AddWithValue("@email", this.Email ?? "");   // corrige a omissão
                    comando.Parameters.AddWithValue("@senha", CriptografarSenha(this.Senha));

                    long count = (long)comando.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao fazer login: " + ex.Message);
                return false;
            }
        }

        public bool RedefinirSenha()
        {
            try
            {
                using (MySqlConnection conexao = new ConexaoBD().Conectar())
                {
                    string query = "UPDATE usuarios SET senha = @senha WHERE email = @email";
                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@email", this.Email);
                    comando.Parameters.AddWithValue("@senha", CriptografarSenha(this.Senha));
                    return comando.ExecuteNonQuery() > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao redefinir senha: " + ex.Message);
                return false;
            }
        }

    }
}
