﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace FocusTime
{
    public partial class TelaLogin : UserControl
    {
        private TelaPrincipal formprincipal;

        public TelaLogin(TelaPrincipal formprincipal)
        {
            InitializeComponent();
            this.formprincipal = formprincipal;
        }

        private void llblCadastros_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TelaCadastro telaCadastro = new TelaCadastro(formprincipal);
            formprincipal.AdicionarUserControl(telaCadastro);
        }

        private void llblRedefinirSenha_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TelaRedefinirSenha telaRedefinir = new TelaRedefinirSenha(formprincipal);
            formprincipal.AdicionarUserControl(telaRedefinir);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(txtLoginOuEmail.Text) && !string.IsNullOrWhiteSpace(txtSenha.Text))
                {
                    string loginOuEmail = txtLoginOuEmail.Text;
                    string senha = txtSenha.Text;

                    Usuarios usuarios = new Usuarios(loginOuEmail, senha);

                    if (!usuarios.FazerLogin())
                    {
                        MessageBox.Show("Usuário ou senha incorretos. Verifique seus dados e tente novamente.");
                        return;
                    }

                    MessageBox.Show("Login feito com sucesso!");

                    TelaListaTarefas telaTarefas = new TelaListaTarefas(formprincipal);
                    formprincipal.AdicionarUserControl(telaTarefas);
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos obrigatórios.");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao fazer o login" + ex.Message);
            }
        }
    }
}
