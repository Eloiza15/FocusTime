﻿namespace FocusTime
{
    partial class TelaListaTarefas
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            dgvTarefas = new DataGridView();
            lblTitulo = new Label();
            lblTituloTarefa = new Label();
            lblDescricao = new Label();
            txtTitulo = new TextBox();
            txtDescricao = new TextBox();
            lblDataLimite = new Label();
            lblStatus = new Label();
            mtxtDataLimite = new MaskedTextBox();
            btnSalvar = new Button();
            btnEditar = new Button();
            btnExcluir = new Button();
            pictureBox1 = new PictureBox();
            cbxStatus = new ComboBox();
            lblId = new Label();
            txtId = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvTarefas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dgvTarefas
            // 
            dgvTarefas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTarefas.Location = new Point(18, 33);
            dgvTarefas.Name = "dgvTarefas";
            dgvTarefas.RowHeadersVisible = false;
            dgvTarefas.Size = new Size(590, 157);
            dgvTarefas.TabIndex = 0;
            dgvTarefas.CellDoubleClick += dgvTarefas_CellDoubleClick;
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.BackColor = Color.DarkSlateGray;
            lblTitulo.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitulo.ForeColor = SystemColors.Window;
            lblTitulo.Location = new Point(243, 9);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(126, 21);
            lblTitulo.TabIndex = 1;
            lblTitulo.Text = "Lista de Tarefas";
            // 
            // lblTituloTarefa
            // 
            lblTituloTarefa.AutoSize = true;
            lblTituloTarefa.Location = new Point(132, 209);
            lblTituloTarefa.Name = "lblTituloTarefa";
            lblTituloTarefa.Size = new Size(41, 15);
            lblTituloTarefa.TabIndex = 2;
            lblTituloTarefa.Text = "Titulo:";
            // 
            // lblDescricao
            // 
            lblDescricao.AutoSize = true;
            lblDescricao.Location = new Point(112, 241);
            lblDescricao.Name = "lblDescricao";
            lblDescricao.Size = new Size(61, 15);
            lblDescricao.TabIndex = 3;
            lblDescricao.Text = "Descrição:";
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(189, 206);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(145, 23);
            txtTitulo.TabIndex = 1;
            // 
            // txtDescricao
            // 
            txtDescricao.Location = new Point(189, 236);
            txtDescricao.Name = "txtDescricao";
            txtDescricao.Size = new Size(145, 23);
            txtDescricao.TabIndex = 2;
            // 
            // lblDataLimite
            // 
            lblDataLimite.AutoSize = true;
            lblDataLimite.Location = new Point(349, 209);
            lblDataLimite.Name = "lblDataLimite";
            lblDataLimite.Size = new Size(70, 15);
            lblDataLimite.TabIndex = 4;
            lblDataLimite.Text = "Data Limite:";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(377, 244);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(42, 15);
            lblStatus.TabIndex = 5;
            lblStatus.Text = "Status:";
            // 
            // mtxtDataLimite
            // 
            mtxtDataLimite.Location = new Point(425, 206);
            mtxtDataLimite.Mask = "00/00/0000";
            mtxtDataLimite.Name = "mtxtDataLimite";
            mtxtDataLimite.Size = new Size(145, 23);
            mtxtDataLimite.TabIndex = 6;
            // 
            // btnSalvar
            // 
            btnSalvar.BackColor = Color.FromArgb(59, 130, 246);
            btnSalvar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalvar.ForeColor = SystemColors.Window;
            btnSalvar.Location = new Point(145, 285);
            btnSalvar.Margin = new Padding(2);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(66, 28);
            btnSalvar.TabIndex = 7;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = false;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // btnEditar
            // 
            btnEditar.BackColor = Color.FromArgb(59, 130, 246);
            btnEditar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEditar.ForeColor = SystemColors.Window;
            btnEditar.Location = new Point(268, 285);
            btnEditar.Margin = new Padding(2);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(66, 28);
            btnEditar.TabIndex = 8;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = false;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnExcluir
            // 
            btnExcluir.BackColor = Color.FromArgb(59, 130, 246);
            btnExcluir.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnExcluir.ForeColor = SystemColors.Window;
            btnExcluir.Location = new Point(391, 285);
            btnExcluir.Margin = new Padding(2);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(66, 28);
            btnExcluir.TabIndex = 9;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = false;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.FocusTimeLogo2;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(39, 27);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // cbxStatus
            // 
            cbxStatus.DropDownStyle = ComboBoxStyle.DropDownList;
            cbxStatus.FormattingEnabled = true;
            cbxStatus.Items.AddRange(new object[] { "Pendente", "Em Andamento", "Concluída" });
            cbxStatus.Location = new Point(425, 241);
            cbxStatus.Name = "cbxStatus";
            cbxStatus.Size = new Size(145, 23);
            cbxStatus.TabIndex = 4;
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Location = new Point(18, 231);
            lblId.Name = "lblId";
            lblId.Size = new Size(21, 15);
            lblId.TabIndex = 11;
            lblId.Text = "ID:";
            // 
            // txtId
            // 
            txtId.Location = new Point(45, 228);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(54, 23);
            txtId.TabIndex = 12;
            // 
            // TelaListaTarefas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(txtId);
            Controls.Add(lblId);
            Controls.Add(cbxStatus);
            Controls.Add(pictureBox1);
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnSalvar);
            Controls.Add(mtxtDataLimite);
            Controls.Add(lblStatus);
            Controls.Add(lblDataLimite);
            Controls.Add(txtDescricao);
            Controls.Add(txtTitulo);
            Controls.Add(lblDescricao);
            Controls.Add(lblTituloTarefa);
            Controls.Add(lblTitulo);
            Controls.Add(dgvTarefas);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "TelaListaTarefas";
            Size = new Size(625, 326);
            Load += TelaListaTarefas_Load;
            ((System.ComponentModel.ISupportInitialize)dgvTarefas).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvTarefas;
        private Label lblTitulo;
        private Label lblTituloTarefa;
        private Label lblDescricao;
        private TextBox txtTitulo;
        private TextBox txtDescricao;
        private Label lblDataLimite;
        private Label lblStatus;
        private TextBox txtStatus;
        private MaskedTextBox mtxtDataLimite;
        private Button btnSalvar;
        private Button btnEditar;
        private Button btnExcluir;
        private PictureBox pictureBox1;
        private ComboBox cbxStatus;
        private Label lblId;
        private TextBox txtId;
    }
}
