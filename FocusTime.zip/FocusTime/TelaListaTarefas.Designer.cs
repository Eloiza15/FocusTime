﻿namespace FocusTime
{
    partial class TelaListaTarefas
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            lblTitulo = new Label();
            lblTituloTarefa = new Label();
            lblDescricao = new Label();
            txtTitulo = new TextBox();
            txtDescricao = new TextBox();
            lblDataLimite = new Label();
            lblStatus = new Label();
            txtStatus = new TextBox();
            mtxtDataLimite = new MaskedTextBox();
            btnSalvar = new Button();
            btnEditar = new Button();
            btnExcluir = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(18, 34);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(590, 152);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.BackColor = Color.DarkSlateGray;
            lblTitulo.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitulo.ForeColor = SystemColors.Window;
            lblTitulo.Location = new Point(243, 10);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(126, 21);
            lblTitulo.TabIndex = 1;
            lblTitulo.Text = "Lista de Tarefas";
            // 
            // lblTituloTarefa
            // 
            lblTituloTarefa.AutoSize = true;
            lblTituloTarefa.Location = new Point(18, 204);
            lblTituloTarefa.Name = "lblTituloTarefa";
            lblTituloTarefa.Size = new Size(43, 17);
            lblTituloTarefa.TabIndex = 2;
            lblTituloTarefa.Text = "Titulo:";
            // 
            // lblDescricao
            // 
            lblDescricao.AutoSize = true;
            lblDescricao.Location = new Point(18, 242);
            lblDescricao.Name = "lblDescricao";
            lblDescricao.Size = new Size(68, 17);
            lblDescricao.TabIndex = 3;
            lblDescricao.Text = "Descrição:";
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(107, 201);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(145, 25);
            txtTitulo.TabIndex = 1;
            // 
            // txtDescricao
            // 
            txtDescricao.Location = new Point(107, 239);
            txtDescricao.Name = "txtDescricao";
            txtDescricao.Size = new Size(145, 25);
            txtDescricao.TabIndex = 2;
            // 
            // lblDataLimite
            // 
            lblDataLimite.AutoSize = true;
            lblDataLimite.Location = new Point(306, 204);
            lblDataLimite.Name = "lblDataLimite";
            lblDataLimite.Size = new Size(76, 17);
            lblDataLimite.TabIndex = 4;
            lblDataLimite.Text = "Data Limite:";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(306, 242);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(46, 17);
            lblStatus.TabIndex = 5;
            lblStatus.Text = "Status:";
            // 
            // txtStatus
            // 
            txtStatus.Location = new Point(425, 239);
            txtStatus.Name = "txtStatus";
            txtStatus.Size = new Size(145, 25);
            txtStatus.TabIndex = 4;
            // 
            // mtxtDataLimite
            // 
            mtxtDataLimite.Location = new Point(425, 201);
            mtxtDataLimite.Mask = "00/00/000";
            mtxtDataLimite.Name = "mtxtDataLimite";
            mtxtDataLimite.Size = new Size(145, 25);
            mtxtDataLimite.TabIndex = 6;
            // 
            // btnSalvar
            // 
            btnSalvar.BackColor = Color.FromArgb(59, 130, 246);
            btnSalvar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSalvar.ForeColor = SystemColors.Window;
            btnSalvar.Location = new Point(145, 279);
            btnSalvar.Margin = new Padding(2);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(66, 32);
            btnSalvar.TabIndex = 7;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = false;
            // 
            // btnEditar
            // 
            btnEditar.BackColor = Color.FromArgb(59, 130, 246);
            btnEditar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEditar.ForeColor = SystemColors.Window;
            btnEditar.Location = new Point(267, 279);
            btnEditar.Margin = new Padding(2);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(66, 32);
            btnEditar.TabIndex = 8;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = false;
            // 
            // btnExcluir
            // 
            btnExcluir.BackColor = Color.FromArgb(59, 130, 246);
            btnExcluir.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnExcluir.ForeColor = SystemColors.Window;
            btnExcluir.Location = new Point(391, 279);
            btnExcluir.Margin = new Padding(2);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(66, 32);
            btnExcluir.TabIndex = 9;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.FocusTimeLogo2;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(39, 31);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // TelaListaTarefas
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(pictureBox1);
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnSalvar);
            Controls.Add(mtxtDataLimite);
            Controls.Add(txtStatus);
            Controls.Add(lblStatus);
            Controls.Add(lblDataLimite);
            Controls.Add(txtDescricao);
            Controls.Add(txtTitulo);
            Controls.Add(lblDescricao);
            Controls.Add(lblTituloTarefa);
            Controls.Add(lblTitulo);
            Controls.Add(dataGridView1);
            Name = "TelaListaTarefas";
            Size = new Size(625, 327);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label lblTitulo;
        private Label lblTituloTarefa;
        private Label lblDescricao;
        private TextBox txtTitulo;
        private TextBox txtDescricao;
        private Label lblDataLimite;
        private Label lblStatus;
        private TextBox txtStatus;
        private MaskedTextBox mtxtDataLimite;
        private Button btnSalvar;
        private Button btnEditar;
        private Button btnExcluir;
        private PictureBox pictureBox1;
    }
}
