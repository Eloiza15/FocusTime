﻿namespace FocusTime
{
    partial class TelaLogin
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            gbxLogin = new GroupBox();
            llblRedefinirSenha = new LinkLabel();
            txtSenha = new TextBox();
            txtLoginOuEmail = new TextBox();
            llblCadastros = new LinkLabel();
            btnLogin = new Button();
            lblSenha = new Label();
            lblLogin = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            gbxLogin.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.FocusTimeLogo2;
            pictureBox1.Location = new Point(363, 70);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(227, 224);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // gbxLogin
            // 
            gbxLogin.BackColor = Color.White;
            gbxLogin.Controls.Add(llblRedefinirSenha);
            gbxLogin.Controls.Add(txtSenha);
            gbxLogin.Controls.Add(txtLoginOuEmail);
            gbxLogin.Controls.Add(llblCadastros);
            gbxLogin.Controls.Add(btnLogin);
            gbxLogin.Controls.Add(lblSenha);
            gbxLogin.Controls.Add(lblLogin);
            gbxLogin.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gbxLogin.Location = new Point(37, 60);
            gbxLogin.Margin = new Padding(2);
            gbxLogin.Name = "gbxLogin";
            gbxLogin.Padding = new Padding(2);
            gbxLogin.Size = new Size(300, 248);
            gbxLogin.TabIndex = 2;
            gbxLogin.TabStop = false;
            gbxLogin.Text = "Login";
            // 
            // llblRedefinirSenha
            // 
            llblRedefinirSenha.AutoSize = true;
            llblRedefinirSenha.Location = new Point(23, 207);
            llblRedefinirSenha.Name = "llblRedefinirSenha";
            llblRedefinirSenha.Size = new Size(234, 15);
            llblRedefinirSenha.TabIndex = 5;
            llblRedefinirSenha.TabStop = true;
            llblRedefinirSenha.Text = "Esqueceu sua Senha? Clique para redefinir! ";
            llblRedefinirSenha.LinkClicked += llblRedefinirSenha_LinkClicked;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(64, 77);
            txtSenha.MaxLength = 8;
            txtSenha.Name = "txtSenha";
            txtSenha.PasswordChar = '*';
            txtSenha.Size = new Size(211, 23);
            txtSenha.TabIndex = 2;
            // 
            // txtLoginOuEmail
            // 
            txtLoginOuEmail.Location = new Point(114, 40);
            txtLoginOuEmail.Name = "txtLoginOuEmail";
            txtLoginOuEmail.Size = new Size(161, 23);
            txtLoginOuEmail.TabIndex = 1;
            // 
            // llblCadastros
            // 
            llblCadastros.AutoSize = true;
            llblCadastros.Location = new Point(28, 177);
            llblCadastros.Name = "llblCadastros";
            llblCadastros.Size = new Size(215, 15);
            llblCadastros.TabIndex = 4;
            llblCadastros.TabStop = true;
            llblCadastros.Text = "Não possui Cadastro? Faça o seu agora!";
            llblCadastros.LinkClicked += llblCadastros_LinkClicked;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.FromArgb(59, 130, 246);
            btnLogin.ForeColor = SystemColors.Window;
            btnLogin.Location = new Point(114, 124);
            btnLogin.Margin = new Padding(2);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(83, 34);
            btnLogin.TabIndex = 3;
            btnLogin.Text = "Fazer Login";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(23, 80);
            lblSenha.Margin = new Padding(2, 0, 2, 0);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(42, 15);
            lblSenha.TabIndex = 3;
            lblSenha.Text = "Senha:";
            // 
            // lblLogin
            // 
            lblLogin.AutoSize = true;
            lblLogin.Location = new Point(23, 43);
            lblLogin.Margin = new Padding(2, 0, 2, 0);
            lblLogin.Name = "lblLogin";
            lblLogin.Size = new Size(89, 15);
            lblLogin.TabIndex = 1;
            lblLogin.Text = "Login ou Email:";
            // 
            // TelaLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            Controls.Add(gbxLogin);
            Controls.Add(pictureBox1);
            Margin = new Padding(2);
            Name = "TelaLogin";
            Size = new Size(625, 371);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            gbxLogin.ResumeLayout(false);
            gbxLogin.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private GroupBox gbxLogin;
        private Label lblSaudações;
        private TextBox txtSenha;
        private TextBox txtLoginOuEmail;
        private LinkLabel llblLogin;
        private Button btnLogin;
        private Label lblSenha;
        private Label lblLogin;
        private LinkLabel llblRedefinirSenha;
        private LinkLabel llblCadastros;
    }
}
