﻿namespace FocusTime
{
    partial class TelaLogin
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            gbxLogin = new GroupBox();
            llblRedefinirSenha = new LinkLabel();
            txtSenha = new TextBox();
            txtLogin = new TextBox();
            llblCadastros = new LinkLabel();
            btnLogin = new Button();
            lblSenha = new Label();
            lblLogin = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            gbxLogin.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.FocusTimeLogo2;
            pictureBox1.Location = new Point(363, 62);
            pictureBox1.Margin = new Padding(2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(227, 198);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // gbxLogin
            // 
            gbxLogin.BackColor = Color.White;
            gbxLogin.Controls.Add(llblRedefinirSenha);
            gbxLogin.Controls.Add(txtSenha);
            gbxLogin.Controls.Add(txtLogin);
            gbxLogin.Controls.Add(llblCadastros);
            gbxLogin.Controls.Add(btnLogin);
            gbxLogin.Controls.Add(lblSenha);
            gbxLogin.Controls.Add(lblLogin);
            gbxLogin.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            gbxLogin.Location = new Point(37, 53);
            gbxLogin.Margin = new Padding(2);
            gbxLogin.Name = "gbxLogin";
            gbxLogin.Padding = new Padding(2);
            gbxLogin.Size = new Size(300, 219);
            gbxLogin.TabIndex = 2;
            gbxLogin.TabStop = false;
            gbxLogin.Text = "Login";
            // 
            // llblRedefinirSenha
            // 
            llblRedefinirSenha.AutoSize = true;
            llblRedefinirSenha.Location = new Point(23, 183);
            llblRedefinirSenha.Name = "llblRedefinirSenha";
            llblRedefinirSenha.Size = new Size(234, 15);
            llblRedefinirSenha.TabIndex = 5;
            llblRedefinirSenha.TabStop = true;
            llblRedefinirSenha.Text = "Esqueceu sua Senha? Clique para redefinir! ";
            llblRedefinirSenha.LinkClicked += llblRedefinirSenha_LinkClicked;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(74, 68);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(201, 23);
            txtSenha.TabIndex = 2;
            // 
            // txtLogin
            // 
            txtLogin.Location = new Point(74, 35);
            txtLogin.Name = "txtLogin";
            txtLogin.Size = new Size(201, 23);
            txtLogin.TabIndex = 1;
            // 
            // llblCadastros
            // 
            llblCadastros.AutoSize = true;
            llblCadastros.Location = new Point(28, 156);
            llblCadastros.Name = "llblCadastros";
            llblCadastros.Size = new Size(215, 15);
            llblCadastros.TabIndex = 4;
            llblCadastros.TabStop = true;
            llblCadastros.Text = "Não possui Cadastro? Faça o seu agora!";
            llblCadastros.LinkClicked += llblCadastros_LinkClicked;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.FromArgb(59, 130, 246);
            btnLogin.ForeColor = SystemColors.Window;
            btnLogin.Location = new Point(114, 109);
            btnLogin.Margin = new Padding(2);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(83, 30);
            btnLogin.TabIndex = 3;
            btnLogin.Text = "Fazer Login";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // lblSenha
            // 
            lblSenha.AutoSize = true;
            lblSenha.Location = new Point(23, 71);
            lblSenha.Margin = new Padding(2, 0, 2, 0);
            lblSenha.Name = "lblSenha";
            lblSenha.Size = new Size(42, 15);
            lblSenha.TabIndex = 3;
            lblSenha.Text = "Senha:";
            // 
            // lblLogin
            // 
            lblLogin.AutoSize = true;
            lblLogin.Location = new Point(22, 38);
            lblLogin.Margin = new Padding(2, 0, 2, 0);
            lblLogin.Name = "lblLogin";
            lblLogin.Size = new Size(40, 15);
            lblLogin.TabIndex = 1;
            lblLogin.Text = "Login:";
            // 
            // TelaLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            Controls.Add(gbxLogin);
            Controls.Add(pictureBox1);
            Margin = new Padding(2);
            Name = "TelaLogin";
            Size = new Size(625, 327);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            gbxLogin.ResumeLayout(false);
            gbxLogin.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private GroupBox gbxLogin;
        private Label lblSaudações;
        private TextBox txtSenha;
        private TextBox txtLogin;
        private LinkLabel llblLogin;
        private Button btnLogin;
        private Label lblSenha;
        private Label lblLogin;
        private LinkLabel llblRedefinirSenha;
        private LinkLabel llblCadastros;
    }
}
