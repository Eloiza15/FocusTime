﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FocusTime
{
    public partial class TelaCadastro : UserControl
    {
        private TelaPrincipal formprincipal;

        public TelaCadastro(TelaPrincipal formprincipal)
        {
            InitializeComponent();
            this.formprincipal = formprincipal;
        }

        private void llblLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            TelaLogin telaLogin = new TelaLogin(formprincipal); 
            formprincipal.AdicionarUserControl(telaLogin);
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(txtNome.Text) &&
                    !string.IsNullOrWhiteSpace(txtLogin.Text) &&
                    !string.IsNullOrWhiteSpace(txtSenha.Text) &&
                    !string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    string nome = txtNome.Text;
                    string login = txtLogin.Text;
                    string senha = txtSenha.Text;
                    string email = txtEmail.Text;

                    Usuarios usuarios = new Usuarios(nome, email, login, senha);

                    if (!Usuarios.verificarEmail(email))
                    {
                        MessageBox.Show("Email inválido.");
                        return;
                    }

                    if (Usuarios.LoginOuEmailExistem(login, email))
                    {
                        MessageBox.Show("Este login ou e-mail já está em uso. Por favor, escolha outro.");
                        return;
                    }

                    if (!usuarios.CadastrarUsuario())
                    {
                        MessageBox.Show("Erro ao cadastrar usuário.");
                        return;
                    }

                    MessageBox.Show("Usuário cadastrado com sucesso!");

                    TelaListaTarefas telaTarefas = new TelaListaTarefas(formprincipal);
                    formprincipal.AdicionarUserControl(telaTarefas);
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos obrigatórios.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao cadastrar usuário: " + ex.Message);
            }
        }
    }
}
