﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FocusTime
{
    public partial class TelaRedefinirSenha : UserControl
    {
        private TelaPrincipal formprincipal;
        public TelaRedefinirSenha(TelaPrincipal formprincipal)
        {
            InitializeComponent();
            this.formprincipal = formprincipal;
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            TelaLogin telaLogin = new TelaLogin(formprincipal);
            formprincipal.AdicionarUserControl(telaLogin);
        }

        private void btnRedefinir_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(txtEmail.Text) && !string.IsNullOrWhiteSpace(txtSenha.Text))
                {
                    string email = txtEmail.Text;
                    string senha = txtSenha.Text;

                    Usuarios usuarios = new Usuarios(email, senha);

                    if (!usuarios.RedefinirSenha())
                    {
                        MessageBox.Show("Não foi possível redefinir a senha. Verifique se o e-mail está correto.");
                        return;
                    }

                    MessageBox.Show("Senha redefinida com sucesso!");
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos obrigatórios.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao redefinir a senha: " + ex.Message);
            }
        }
    }
}
